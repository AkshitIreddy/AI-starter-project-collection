# Brain-Tumor-Detection-and-Segmentation
Convolutional neural network to detect the tumor & Unet for segmenting the tumor and anvil for for creating the webapp.
