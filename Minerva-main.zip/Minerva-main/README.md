# Minerva
Discord Chatbot for MIT Bengaluru
