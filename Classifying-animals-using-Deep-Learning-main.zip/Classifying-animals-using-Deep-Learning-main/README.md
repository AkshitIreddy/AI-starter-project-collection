# Classifying-animals-
This model has been trained on a pretrained model and it can classify animals by looking at their pictures
