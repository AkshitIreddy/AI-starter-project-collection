the face_and_facial_expressions_pic.py file needs pictures in both known and unknown folder but the face_and_facial_expressions_webcam_videofile.py uses webcam or videofile 
as output and pictures of the user from known folder to recognise the user.
