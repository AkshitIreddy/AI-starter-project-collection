import face_recognition
import os
import cv2
from fer import FER

#Predefined values
known_faces_directory = 'known_faces'
unknown_faces_directory = 'unknown_faces'
model = 'hog'
tolerance = 0.6
color = [0, 255, 0]
thickness = 2
font_thickness = 2

known_faces_encoding = []
known_faces_names = []

# folder_name refers to the folders with the pictures of one person
for folder_name in os.listdir(known_faces_directory):
    #image_name refers to the pictures in the folder
    for image_file in os.listdir(f'{known_faces_directory}/{folder_name}'):
        # Load the image
        image = face_recognition.load_image_file(f'{known_faces_directory}/{folder_name}/{image_file}')
        try:
            # Encode the first face found in the picture
            image_encoding = face_recognition.face_encodings(image)[0]
            #save the image encoding to a list
            known_faces_encoding.append(image_encoding)
            #save the name of the person of the image that is being encoded to a list
            known_faces_names.append(folder_name)
        except Exception :
            pass

for image_file in os.listdir(f'{unknown_faces_directory}'):
    image = face_recognition.load_image_file(f'{unknown_faces_directory}/{image_file}')
    #find the location of all faces in the image
    unknown_face_locations = face_recognition.face_locations(image, model= model)
    #encode each face in the image
    unknown_face_encodings = face_recognition.face_encodings(image, unknown_face_locations)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    i = 0
    
    for unknown_face_encoding , unknown_face_location in zip(unknown_face_encodings, unknown_face_locations):
        #compare the unknown faces to the known ones
        results = face_recognition.compare_faces(known_faces_encoding , unknown_face_encoding , tolerance)

        if True in results:
            name = known_faces_names[results.index(True)]
            top_left = (unknown_face_location[3], unknown_face_location[0])
            bottom_right = (unknown_face_location[1] + 45 , unknown_face_location[2])
            cv2.rectangle(image , top_left , bottom_right , color , thickness)
            
            ###detect and put the name and the emotion of the person under their face
            
            #detect the emotion
            detector = FER()
            result = detector.detect_emotions(image)
            emotions = result[i]["emotions"]
            text = str(name) + str(" ") + str(max(emotions, key=emotions.get))
            i += 1
            
            #put the name and emotion
            top_left = (unknown_face_location[3], unknown_face_location[2] )
            bottom_right = (unknown_face_location[1] + 45 , unknown_face_location[2] + 25)
            cv2.rectangle(image,top_left,bottom_right,color,cv2.FILLED)
            cv2.putText(image, text, (unknown_face_location[3] + 10, unknown_face_location[2] + 20),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), font_thickness)

    cv2.imshow(image_file, image)
    cv2.waitKey(0)
    cv2.destroyWindow(image_file)
