# Face-and-Facial-Expressions-Recogniser
This model can identify the person and their facial expressions.
