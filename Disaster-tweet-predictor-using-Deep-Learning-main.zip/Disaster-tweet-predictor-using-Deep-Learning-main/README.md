# Disaster-tweet-predictor
This model works similar to a sentiment analysis model but instead of predicting whether a comment/tweet is positive or negative this model predicts whether the tweet contains any information about a disaster or crime happening.
