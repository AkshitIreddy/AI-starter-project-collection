# Covid-Classifier
This model classify's whether or not a person has covid by looking at their lung scans
