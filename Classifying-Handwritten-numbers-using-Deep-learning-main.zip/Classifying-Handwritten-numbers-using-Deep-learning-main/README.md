# Classifying-Handwritten-numbers
This model can predict what the number is by looking at the picture of the number.
