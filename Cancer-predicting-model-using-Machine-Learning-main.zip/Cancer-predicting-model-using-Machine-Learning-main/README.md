# Cancer-predicting-model
This model can predict whether or not a person has cancer 
