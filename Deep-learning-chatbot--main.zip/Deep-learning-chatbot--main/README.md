# Deep-learning-chatbot-
This chatbot uses a json file with intents as a dataset, the chatbot's performance depends on the dataset used.
