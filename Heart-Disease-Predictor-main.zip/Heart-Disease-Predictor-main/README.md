# Heart-Disease-Predictor
This model uses xgboost classifier to predict whether a person has heart disease.
