# Movie-Recommender-System
The movies recommender file will recommend movies based on features like the plot, actors and director of the movie.
