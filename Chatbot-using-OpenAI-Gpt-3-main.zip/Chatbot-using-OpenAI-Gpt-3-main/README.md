# Chatbot-using-OpenAI-Gpt-3
I used OpenAI's Gpt-3 with a speech to text and text to speech module to make a chatbot that can voice chat.
To run this code you will need the following python modules: pyttsx3, speech_recognition, openai. You will also require an openai account from which you can access your openai api key.
