# discord-bot

First pip install discord.py
link on tutorial :  https://pypi.org/project/discord.py/

1. make a discord account
2. make a discord server
3. go to discord developer portal : https://discord.com/developers/applications
4. login there 
5. once login is succcesful create a new application in the developer portal by clicking on applications on the left bar where u should see 'new application' on the top right corner click on that and create a new application.
6. once the application is created create a new bot by clicking on the bot on the left bar and then click create new bot
7. once you create the bot you should see a TOKEN. copy that and save it.
8. Done! you now have a bot all you need to do now is add your bot to your server which i will explain
9. go to OAUTH2, go to url generator, in scopes select bot then and then go below to bot permissions and you will see a list of permission for your bot. select read messsage history and send messages.
10. now copy the url and paste in search bar and click enter. now it will open a discord page where it will show the list of servers you can add it to. add it to the newly made server that you made in step 2.
11. And Done! Check your server you should see your bot now lets move to code now. There will be a code file called beginner.py in the github repository. Open it and read it you might not be able read/run it if you don't have python installed.
12. install python idle it barely takes any time once you finish installing open the code beginner.py. link to install python idle is: https://www.python.org/downloads/

